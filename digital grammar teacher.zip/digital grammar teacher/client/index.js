const charval = document.getElementById("textarea");
let totalCount = document.getElementById("total-conter");
let remainingCoutn = document.getElementById("remaining-counter");
const logoutButton = document.getElementById("logout-button")
let para = document.getElementById('para');

let userChar = 0;

let username = localStorage.getItem("name");
username = JSON.parse(username)
const greet = `Hi!! ${username}, `;
para.append(greet)


const updateCounter = () => {
  userChar = charval.value.length;

  totalCount.innerText = userChar;

  remainingCoutn.innerText = 200 - userChar;
};

charval.addEventListener("keyup", () => updateCounter());

const copyText = () => {
  charval.select();
  charval.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(charval.value);
};

logoutButton.addEventListener("click" , function()
{
  var request = new XMLHttpRequest();
  request.open("GET" , "/logout")
  request.send();

  request.addEventListener("load" , function()
  {
    if(request.responseText === 200)
    {
      localStorage.clear();
    }
      window.location.href ="/";
  })
})