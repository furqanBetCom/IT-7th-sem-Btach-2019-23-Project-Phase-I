const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: "<EMAIL ADDRESS>",
        pass: "<EMAIL PASSWORD>"
    }
});

module.exports =  {
  sendMailToUser: function sendMail(toMail,html, callback) {

let message = {
    from: "<SENDER'S EMAIL ADDRESS>",
    to: toMail,
    subject: "Digital Grammar Teacher",
    html: html
}
   transporter.sendMail(message, function(err, info) {
    if (err) {
        console.log('error',err);
        callback(false)
    } else {
        console.log("info",info);
        callback(true);
    }
  })
  }
}
